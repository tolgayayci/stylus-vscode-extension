# Licensing Information

Copyright 2022-2023 Offchain Labs, Inc.

Copyright assignment and [DCO sign-off](DCO.txt) is required to contribute to this project.

Except as otherwise noted (below and/or in individual files), this project is licensed under the Apache License, Version 2.0 ([`LICENSE-APACHE`](Apache-2.0) or http://www.apache.org/licenses/LICENSE-2.0) or the MIT license, ([`LICENSE-MIT`](MIT) or http://opensource.org/licenses/MIT), at your option.

Each Stylus logo is a service mark of Offchain Labs (collectively, the "Offchain Labs Trademarks"). Offchain Labs reserves all rights in the Offchain Labs Trademarks and nothing herein or in these licenses should be construed as granting, by implication, estoppel, or otherwise, any license or right to use any of Offchain Labs Trademarks without Offchain Labs' prior written permission in each instance. All goodwill generated from the use of Offchain Labs Trademarks will inure to our exclusive benefit.
